
import React, { useRef, useEffect, useState, useCallback } from 'react';
import { GAME_CONFIG } from '../constants';
import { GameObject, Bullet, Asteroid, GameStats } from '../types';

interface AsteroidsGameProps {
  onGameOver: (stats: GameStats) => void;
  username: string;
}

const AsteroidsGame: React.FC<AsteroidsGameProps> = ({ onGameOver, username }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [startTime] = useState(Date.now());
  const [asteroidsDestroyed, setAsteroidsDestroyed] = useState(0);

  // Game state references (to avoid re-renders)
  const shipRef = useRef<GameObject>({ x: 0, y: 0, vx: 0, vy: 0, radius: GAME_CONFIG.SHIP_SIZE, rotation: -Math.PI / 2 });
  const bulletsRef = useRef<Bullet[]>([]);
  const asteroidsRef = useRef<Asteroid[]>([]);
  const keysRef = useRef<{ [key: string]: boolean }>({});

  const initGame = useCallback((width: number, height: number) => {
    shipRef.current = {
      x: width / 2,
      y: height / 2,
      vx: 0,
      vy: 0,
      radius: GAME_CONFIG.SHIP_SIZE,
      rotation: -Math.PI / 2,
    };
    
    // Initial asteroids
    const initialAsteroids: Asteroid[] = [];
    for (let i = 0; i < GAME_CONFIG.MAX_ASTEROIDS; i++) {
      initialAsteroids.push(createAsteroid(width, height));
    }
    asteroidsRef.current = initialAsteroids;
  }, []);

  const createAsteroid = (width: number, height: number, x?: number, y?: number, size: 'large' | 'medium' | 'small' = 'large'): Asteroid => {
    const angle = Math.random() * Math.PI * 2;
    const speed = GAME_CONFIG.ASTEROID_MIN_SPEED + Math.random() * (GAME_CONFIG.ASTEROID_MAX_SPEED - GAME_CONFIG.ASTEROID_MIN_SPEED);
    const radius = size === 'large' ? 40 : size === 'medium' ? 20 : 10;
    
    // If no position provided, spawn far from center
    let spawnX = x ?? Math.random() * width;
    let spawnY = y ?? Math.random() * height;
    
    if (x === undefined) {
      while (Math.hypot(spawnX - width/2, spawnY - height/2) < 200) {
        spawnX = Math.random() * width;
        spawnY = Math.random() * height;
      }
    }

    return {
      x: spawnX,
      y: spawnY,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      radius,
      size,
    };
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initGame(canvas.width, canvas.height);
    };

    window.addEventListener('resize', resize);
    resize();

    const handleKeyDown = (e: KeyboardEvent) => keysRef.current[e.code] = true;
    const handleKeyUp = (e: KeyboardEvent) => keysRef.current[e.code] = false;
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    let animationId: number;
    let lastFire = 0;

    const gameLoop = () => {
      const { width, height } = canvas;
      ctx.fillStyle = '#020617';
      ctx.fillRect(0, 0, width, height);

      // Draw background stars
      ctx.fillStyle = '#ffffff';
      for(let i=0; i<50; i++) {
        const x = (i * 137.5) % width;
        const y = (i * 222.5) % height;
        ctx.fillRect(x, y, 1, 1);
      }

      const ship = shipRef.current;

      // Update Ship
      if (keysRef.current['ArrowLeft'] || keysRef.current['KeyA']) ship.rotation! -= GAME_CONFIG.SHIP_ROTATION_SPEED;
      if (keysRef.current['ArrowRight'] || keysRef.current['KeyD']) ship.rotation! += GAME_CONFIG.SHIP_ROTATION_SPEED;
      if (keysRef.current['ArrowUp'] || keysRef.current['KeyW']) {
        ship.vx += Math.cos(ship.rotation!) * GAME_CONFIG.SHIP_ACCEL;
        ship.vy += Math.sin(ship.rotation!) * GAME_CONFIG.SHIP_ACCEL;
      }

      ship.x += ship.vx;
      ship.y += ship.vy;
      ship.vx *= GAME_CONFIG.SHIP_FRICTION;
      ship.vy *= GAME_CONFIG.SHIP_FRICTION;

      // Wrap Ship
      if (ship.x < 0) ship.x = width;
      if (ship.x > width) ship.x = 0;
      if (ship.y < 0) ship.y = height;
      if (ship.y > height) ship.y = 0;

      // Draw Ship
      ctx.save();
      ctx.translate(ship.x, ship.y);
      ctx.rotate(ship.rotation!);
      ctx.strokeStyle = '#60a5fa';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(15, 0);
      ctx.lineTo(-10, 10);
      ctx.lineTo(-5, 0);
      ctx.lineTo(-10, -10);
      ctx.closePath();
      ctx.stroke();
      if (keysRef.current['ArrowUp'] || keysRef.current['KeyW']) {
          ctx.strokeStyle = '#f97316';
          ctx.beginPath();
          ctx.moveTo(-7, 0);
          ctx.lineTo(-15, 0);
          ctx.stroke();
      }
      ctx.restore();

      // Fire Bullet
      if (keysRef.current['Space'] && Date.now() - lastFire > 250) {
        bulletsRef.current.push({
          x: ship.x + Math.cos(ship.rotation!) * 15,
          y: ship.y + Math.sin(ship.rotation!) * 15,
          vx: Math.cos(ship.rotation!) * GAME_CONFIG.BULLET_SPEED + ship.vx,
          vy: Math.sin(ship.rotation!) * GAME_CONFIG.BULLET_SPEED + ship.vy,
          radius: 2,
          life: GAME_CONFIG.BULLET_LIFE,
        });
        lastFire = Date.now();
      }

      // Update and Draw Bullets
      bulletsRef.current = bulletsRef.current.filter(b => b.life > 0);
      bulletsRef.current.forEach(b => {
        b.x += b.vx;
        b.y += b.vy;
        b.life--;
        // Wrap bullets
        if (b.x < 0) b.x = width;
        if (b.x > width) b.x = 0;
        if (b.y < 0) b.y = height;
        if (b.y > height) b.y = 0;

        ctx.fillStyle = '#f8fafc';
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
        ctx.fill();
      });

      // Update and Draw Asteroids
      asteroidsRef.current.forEach((a, aIdx) => {
        a.x += a.vx;
        a.y += a.vy;

        // Wrap Asteroids
        if (a.x < -50) a.x = width + 50;
        if (a.x > width + 50) a.x = -50;
        if (a.y < -50) a.y = height + 50;
        if (a.y > height + 50) a.y = -50;

        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(a.x, a.y, a.radius, 0, Math.PI * 2);
        ctx.stroke();

        // Check Collision with Ship
        const distShip = Math.hypot(a.x - ship.x, a.y - ship.y);
        if (distShip < a.radius + ship.radius) {
          setLives(prev => {
            const next = prev - 1;
            if (next <= 0) {
              onGameOver({
                score: score,
                asteroidsDestroyed: asteroidsDestroyed,
                timePlayed: (Date.now() - startTime) / 1000
              });
            }
            // Respawn ship in center safely-ish
            ship.x = width / 2;
            ship.y = height / 2;
            ship.vx = 0;
            ship.vy = 0;
            return next;
          });
        }

        // Check Collision with Bullets
        bulletsRef.current.forEach((b, bIdx) => {
          const dist = Math.hypot(a.x - b.x, a.y - b.y);
          if (dist < a.radius + b.radius) {
            // Destroy bullet
            b.life = 0;
            // Split or destroy asteroid
            if (a.size === 'large') {
              asteroidsRef.current.push(createAsteroid(width, height, a.x, a.y, 'medium'));
              asteroidsRef.current.push(createAsteroid(width, height, a.x, a.y, 'medium'));
            } else if (a.size === 'medium') {
              asteroidsRef.current.push(createAsteroid(width, height, a.x, a.y, 'small'));
              asteroidsRef.current.push(createAsteroid(width, height, a.x, a.y, 'small'));
            }
            asteroidsRef.current.splice(aIdx, 1);
            setScore(s => s + (a.size === 'large' ? 100 : a.size === 'medium' ? 200 : 500));
            setAsteroidsDestroyed(prev => prev + 1);
          }
        });
      });

      // Ensure some asteroids exist
      if (asteroidsRef.current.length < 3) {
        asteroidsRef.current.push(createAsteroid(width, height));
      }

      animationId = requestAnimationFrame(gameLoop);
    };

    animationId = requestAnimationFrame(gameLoop);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [score, asteroidsDestroyed, startTime, onGameOver, initGame]);

  return (
    <div className="relative w-full h-screen">
      <canvas ref={canvasRef} className="block cursor-crosshair" />
      
      {/* UI Overlay */}
      <div className="absolute top-0 left-0 p-6 pointer-events-none w-full flex justify-between items-start">
        <div className="bg-slate-900/60 backdrop-blur-md border border-slate-700 p-4 rounded-2xl shadow-xl">
          <div className="text-xs text-blue-400 font-orbitron uppercase tracking-widest mb-1">Piloto</div>
          <div className="text-xl font-bold font-orbitron text-white">{username}</div>
        </div>

        <div className="bg-slate-900/60 backdrop-blur-md border border-slate-700 p-4 rounded-2xl shadow-xl text-center min-w-[120px]">
          <div className="text-xs text-purple-400 font-orbitron uppercase tracking-widest mb-1">Puntos</div>
          <div className="text-2xl font-bold font-orbitron text-white">{score}</div>
        </div>

        <div className="bg-slate-900/60 backdrop-blur-md border border-slate-700 p-4 rounded-2xl shadow-xl text-right">
          <div className="text-xs text-red-400 font-orbitron uppercase tracking-widest mb-1">Escudos</div>
          <div className="flex gap-1 justify-end">
            {[...Array(3)].map((_, i) => (
              <div 
                key={i} 
                className={`w-6 h-2 rounded-full transition-all duration-300 ${i < lives ? 'bg-red-500 shadow-lg shadow-red-900/50' : 'bg-slate-800'}`}
              ></div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-slate-500 text-xs font-orbitron flex gap-4">
          <span>[W/UP] PROPULSIÓN</span>
          <span>[A/D/LEFT/RIGHT] ROTAR</span>
          <span>[SPACE] DISPARAR</span>
      </div>
    </div>
  );
};

export default AsteroidsGame;
