
import React, { useEffect, useState } from 'react';
import { GameStats } from '../types';
import { getAIPilotAnalysis } from '../services/geminiService';

interface AISummaryProps {
  stats: GameStats;
  username: string;
  onRestart: () => void;
}

const AISummary: React.FC<AISummaryProps> = ({ stats, username, onRestart }) => {
  const [analysis, setAnalysis] = useState<string>('Analizando registros de vuelo...');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalysis = async () => {
      const result = await getAIPilotAnalysis(stats, username);
      setAnalysis(result);
      setLoading(false);
    };
    fetchAnalysis();
  }, [stats, username]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 p-6">
      <div className="max-w-2xl w-full bg-slate-900/50 backdrop-blur-2xl border border-slate-800 rounded-3xl p-8 shadow-2xl">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-orbitron font-bold text-white mb-2">MISIÓN FINALIZADA</h2>
          <div className="h-1 w-24 bg-blue-600 mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-10">
          <div className="bg-slate-800/50 p-4 rounded-2xl text-center border border-slate-700">
            <div className="text-xs text-slate-400 font-orbitron mb-1">PUNTOS</div>
            <div className="text-2xl font-bold text-blue-400">{stats.score}</div>
          </div>
          <div className="bg-slate-800/50 p-4 rounded-2xl text-center border border-slate-700">
            <div className="text-xs text-slate-400 font-orbitron mb-1">OBJETIVOS</div>
            <div className="text-2xl font-bold text-purple-400">{stats.asteroidsDestroyed}</div>
          </div>
          <div className="bg-slate-800/50 p-4 rounded-2xl text-center border border-slate-700">
            <div className="text-xs text-slate-400 font-orbitron mb-1">TIEMPO (S)</div>
            <div className="text-2xl font-bold text-green-400">{Math.floor(stats.timePlayed)}</div>
          </div>
        </div>

        <div className="bg-blue-900/10 border border-blue-900/30 rounded-2xl p-6 mb-10 relative">
          <div className="absolute -top-3 left-6 bg-blue-600 px-3 py-1 rounded-md text-[10px] font-orbitron text-white">
            INFORME DE IA CAPITÁN
          </div>
          <div className={`text-slate-200 leading-relaxed italic ${loading ? 'animate-pulse' : ''}`}>
             "{analysis}"
          </div>
        </div>

        <button
          onClick={onRestart}
          className="w-full bg-slate-100 hover:bg-white text-slate-950 font-bold py-4 rounded-xl shadow-lg transition-all transform active:scale-95 font-orbitron"
        >
          NUEVA MISIÓN
        </button>
      </div>
    </div>
  );
};

export default AISummary;
