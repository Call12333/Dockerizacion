
import React, { useState } from 'react';
import LoginForm from './components/LoginForm';
import AsteroidsGame from './components/AsteroidsGame';
import AISummary from './components/AISummary';
import { AppView, User, GameStats } from './types';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('login');
  const [user, setUser] = useState<User | null>(null);
  const [lastStats, setLastStats] = useState<GameStats | null>(null);

  const handleLogin = (username: string) => {
    setUser({ username });
    setView('game');
  };

  const handleGameOver = (stats: GameStats) => {
    setLastStats(stats);
    setView('summary');
  };

  const handleRestart = () => {
    setView('game');
  };

  return (
    <main className="w-full h-screen select-none">
      {view === 'login' && <LoginForm onLogin={handleLogin} />}
      
      {view === 'game' && user && (
        <AsteroidsGame 
          username={user.username} 
          onGameOver={handleGameOver} 
        />
      )}
      
      {view === 'summary' && user && lastStats && (
        <AISummary 
          username={user.username} 
          stats={lastStats} 
          onRestart={handleRestart} 
        />
      )}
    </main>
  );
};

export default App;
