
export type AppView = 'login' | 'game' | 'summary';

export interface User {
  username: string;
}

export interface GameStats {
  score: number;
  asteroidsDestroyed: number;
  timePlayed: number;
}

export interface GameObject {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  rotation?: number;
}

export interface Bullet extends GameObject {
  life: number;
}

export interface Asteroid extends GameObject {
  size: 'large' | 'medium' | 'small';
}
