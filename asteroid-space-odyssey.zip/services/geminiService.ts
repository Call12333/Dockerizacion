
import { GoogleGenAI } from "@google/genai";
import { GameStats } from "../types";

export const getAIPilotAnalysis = async (stats: GameStats, username: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `
      Eres un Capitán de Flota Espacial veterano. Analiza el desempeño del recluta "${username}".
      Estadísticas de la misión:
      - Puntos: ${stats.score}
      - Asteroides destruidos: ${stats.asteroidsDestroyed}
      - Tiempo de vuelo: ${Math.floor(stats.timePlayed)} segundos.

      Proporciona un informe breve (máximo 100 palabras) en español, con un tono militar pero alentador. 
      Si el puntaje es bajo, dale un consejo de vuelo. Si es alto, felicítalo por su valentía.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "La comunicación con el centro de mando se ha perdido, pero sabemos que hiciste un gran esfuerzo, piloto.";
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "Error en la conexión con la IA de la flota. ¡Sigue entrenando!";
  }
};
